export type CrimeCategory =
  | 'Cyber Crime'
  | 'Violent Crime'
  | 'Property Crime'
  | 'Organized Crime'
  | 'Narcotics'
  | 'Financial Fraud';

type Severity = 'Low' | 'Medium' | 'High' | 'Critical';
type CaseStatus = 'Under Investigation' | 'Charge Sheet Filed' | 'Solved' | 'Pending';
type TimeOfDay = 'Morning (06:00-12:00)' | 'Afternoon (12:00-17:00)' | 'Evening (17:00-22:00)' | 'Night (22:00-06:00)';

export interface GPSLocation {
  lat: number;
  lng: number;
}

export interface Incident {
  id: string;
  firNumber: string;
  district: string;
  policeStation: string;
  crimeCategory: CrimeCategory;
  crimeSubtype: string;
  dateTime: string;
  timeOfDay: TimeOfDay;
  locationName: string;
  coordinates: GPSLocation;
  severity: Severity;
  status: CaseStatus;
  suspectIds: string[];
  victimName: string;
  modusOperandi: string;
  moTags: string[];
  socioEconomicContext: {
    urbanizationLevel: 'High' | 'Medium' | 'Low';
    unemploymentRate: number;
    povertyIndex: number;
    populationDensitySqKm: number;
  };
  narrative: string;
  isAnomaly: boolean;
  anomalyReason?: string;
  stolenValueINR?: number;
}

export interface Suspect {
  id: string;
  name: string;
  alias?: string;
  age: number;
  gender: string;
  district: string;
  primaryStation: string;
  riskScore: number; // 0 - 100
  moPattern: string;
  associatedCrimeTypes: CrimeCategory[];
  knownAssociates: string[]; // suspect IDs
  linkedIncidentIds: string[];
  gangName?: string;
  status: 'Active' | 'Absconding' | 'In Custody' | 'Under Surveillance';
  lastKnownLocation: string;
  phoneNumber?: string;
  vehicleRegNo?: string;
}

export interface DistrictSummary {
  districtName: string;
  headquarters: string;
  policeStationsCount: number;
  totalIncidents: number;
  solvedRatePercent: number;
  highRiskHotspotsCount: number;
  urbanizationPercent: number;
  unemploymentPercent: number;
  literacyPercent: number;
  policePerLakhCitizens: number;
  dominantCrimeCategory: CrimeCategory;
  coordinates: GPSLocation;
}

export interface NetworkNode {
  id: string;
  label: string;
  type: 'Suspect' | 'Incident' | 'Location' | 'Gang' | 'Vehicle' | 'MOTag' | 'Phone';
  category?: string;
  riskScore?: number;
  details?: Record<string, any>;
  x?: number;
  y?: number;
}

export interface NetworkEdge {
  id: string;
  source: string;
  target: string;
  relationship: 'LINKED_TO' | 'ASSOCIATE_OF' | 'PERPETRATED_AT' | 'OPERATES_IN' | 'USED_MO' | 'MEMBER_OF' | 'CONTACTED';
  strength?: number;
  label?: string;
}

export interface PredictiveRiskForecast {
  district: string;
  stationName: string;
  predictedRiskScore: number;
  trendDirection: 'Increasing' | 'Stable' | 'Decreasing';
  primaryRiskDrivers: string[];
  forecastedCrimeTypes: CrimeCategory[];
  recommendedDeployment: {
    pcrVansNeeded: number;
    patrolTiming: string;
    focusHotspotAreas: string[];
  };
}

export interface CatalystServiceMapping {
  capabilityId: number;
  capabilityName: string;
  requiredCatalystService: string;
  kspPlatformImplementation: string;
}

export interface ERDTable {
  tableName: string;
  description: string;
  columns: {
    name: string;
    type: string;
    isPrimary?: boolean;
    isForeign?: boolean;
    references?: string;
    description: string;
  }[];
}
