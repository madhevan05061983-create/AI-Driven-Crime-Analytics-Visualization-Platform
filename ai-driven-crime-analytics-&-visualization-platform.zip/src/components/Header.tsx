import React from "react";
import { Shield, MapPin, AlertTriangle, Cpu, FileText, Database, PlusCircle, MessageSquare } from "lucide-react";

interface HeaderProps {
  activeTab: "map" | "network" | "predictive" | "ai-hub" | "catalyst";
  setActiveTab: (tab: "map" | "network" | "predictive" | "ai-hub" | "catalyst") => void;
  selectedDistrict: string;
  setSelectedDistrict: (district: string) => void;
  districtsList: string[];
  onOpenIngestModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  selectedDistrict,
  setSelectedDistrict,
  districtsList,
  onOpenIngestModal,
}) => {
  return (
    <header className="bg-slate-900/90 backdrop-blur-md text-slate-100 border-b border-slate-800 sticky top-0 z-50 shadow-2xl">
      {/* Mission Control Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Left: KSP Brand & Title */}
        <div className="flex items-center space-x-3.5">
          <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center font-bold text-white text-xl shadow-lg shadow-indigo-600/30 shrink-0">
            K
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-base sm:text-lg font-bold tracking-wider text-white uppercase leading-tight">
                KSP Crime Analytics Platform
              </h1>
              <span className="hidden sm:inline-flex items-center text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800/60 uppercase">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse mr-1"></span>
                Catalyst System Active
              </span>
            </div>
            <p className="text-[10px] text-indigo-400 font-mono uppercase tracking-[0.2em] mt-0.5">
              Intelligence Hub • State Crime Records Bureau HQ
            </p>
          </div>
        </div>

        {/* Right Controls: Jurisdiction & Quick Action */}
        <div className="flex items-center space-x-3 sm:space-x-6">
          {/* District Switcher */}
          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs">
            <MapPin className="w-3.5 h-3.5 text-indigo-400 mr-2 shrink-0" />
            <div className="flex flex-col">
              <span className="text-[9px] text-slate-500 uppercase font-mono hidden sm:inline">Jurisdiction</span>
              <select
                value={selectedDistrict}
                onChange={(e) => setSelectedDistrict(e.target.value)}
                className="bg-transparent text-slate-200 font-semibold focus:outline-none cursor-pointer text-xs"
              >
                <option value="ALL" className="bg-slate-900 text-slate-200">
                  Karnataka State Wide (All Districts)
                </option>
                {districtsList.map((dist) => (
                  <option key={dist} value={dist} className="bg-slate-900 text-slate-200">
                    {dist}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="h-8 w-px bg-slate-800 hidden md:block"></div>

          {/* Quick Action: Ingest Record */}
          <button
            onClick={onOpenIngestModal}
            className="inline-flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-3.5 py-2 rounded-lg transition-all shadow-md shadow-indigo-600/20 cursor-pointer"
            title="Ingest raw FIR / Crime record into SCRB database"
          >
            <PlusCircle className="w-4 h-4" />
            <span className="hidden md:inline">Ingest FIR Record</span>
          </button>
        </div>
      </div>

      {/* Ticker / Alert Bar */}
      <div className="bg-slate-950 border-t border-b border-slate-800/80 px-4 py-1.5 text-xs text-slate-300 flex items-center overflow-x-auto whitespace-nowrap scrollbar-none">
        <div className="flex items-center space-x-2 text-rose-400 font-semibold shrink-0 mr-4 font-mono text-[11px]">
          <AlertTriangle className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
          <span className="uppercase tracking-wider">Red-Zone Alert:</span>
        </div>
        <div className="flex items-center space-x-6 text-slate-300 font-mono text-[11px]">
          <span className="inline-flex items-center">
            <span className="w-2 h-2 rounded-full bg-rose-500 mr-1.5 animate-ping"></span>
            <strong className="text-indigo-300 mr-1">Bengaluru Urban:</strong> +34% Cyber Fraud spike in Indiranagar
          </span>
          <span className="text-slate-700">•</span>
          <span>
            <strong className="text-indigo-300 mr-1">Belagavi NH-48:</strong> High-risk night highway truck ambush corridor active
          </span>
          <span className="text-slate-700">•</span>
          <span>
            <strong className="text-indigo-300 mr-1">Mangaluru:</strong> Multi-district crypto extortion network linked via Gemini AI
          </span>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex space-x-1 overflow-x-auto scrollbar-none py-1">
        <button
          onClick={() => setActiveTab("map")}
          className={`flex items-center space-x-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
            activeTab === "map"
              ? "bg-indigo-600/20 text-indigo-300 border border-indigo-500/50 shadow-inner"
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border border-transparent"
          }`}
        >
          <MapPin className="w-4 h-4 text-indigo-400" />
          <span>Spatiotemporal Clusters</span>
        </button>

        <button
          onClick={() => setActiveTab("network")}
          className={`flex items-center space-x-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
            activeTab === "network"
              ? "bg-indigo-600/20 text-indigo-300 border border-indigo-500/50 shadow-inner"
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border border-transparent"
          }`}
        >
          <Cpu className="w-4 h-4 text-indigo-400" />
          <span>Network & Link Analysis</span>
        </button>

        <button
          onClick={() => setActiveTab("predictive")}
          className={`flex items-center space-x-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
            activeTab === "predictive"
              ? "bg-indigo-600/20 text-indigo-300 border border-indigo-500/50 shadow-inner"
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border border-transparent"
          }`}
        >
          <AlertTriangle className="w-4 h-4 text-indigo-400" />
          <span>Predictive Risk Scoring</span>
        </button>

        <button
          onClick={() => setActiveTab("ai-hub")}
          className={`flex items-center space-x-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
            activeTab === "ai-hub"
              ? "bg-indigo-600/20 text-indigo-300 border border-indigo-500/50 shadow-inner"
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border border-transparent"
          }`}
        >
          <MessageSquare className="w-4 h-4 text-indigo-400" />
          <span>Gemini Intelligence Hub</span>
        </button>

        <button
          onClick={() => setActiveTab("catalyst")}
          className={`flex items-center space-x-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
            activeTab === "catalyst"
              ? "bg-indigo-600/20 text-indigo-300 border border-indigo-500/50 shadow-inner"
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border border-transparent"
          }`}
        >
          <Database className="w-4 h-4 text-indigo-400" />
          <span>Database ERD & Catalyst Spec</span>
        </button>
      </div>
    </header>
  );
};
