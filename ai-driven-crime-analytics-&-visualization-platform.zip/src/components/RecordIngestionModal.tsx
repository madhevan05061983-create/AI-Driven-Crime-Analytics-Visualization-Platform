import React, { useState } from "react";
import { Incident, CrimeCategory } from "../types/crime";
import { X, PlusCircle, FileSpreadsheet, CheckCircle2 } from "lucide-react";

interface RecordIngestionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddIncident: (newInc: Incident) => void;
  districtsList: string[];
}

export const RecordIngestionModal: React.FC<RecordIngestionModalProps> = ({
  isOpen,
  onClose,
  onAddIncident,
  districtsList,
}) => {
  const [district, setDistrict] = useState<string>("Bengaluru Urban");
  const [station, setStation] = useState<string>("Electronic City PS");
  const [category, setCategory] = useState<CrimeCategory>("Cyber Crime");
  const [subtype, setSubtype] = useState<string>("WhatsApp Crypto Fraud");
  const [timeSlot, setTimeSlot] = useState<any>("Night (22:00-06:00)");
  const [locationName, setLocationName] = useState<string>("Phase 1 Tech Park Circle");
  const [victimName, setVictimName] = useState<string>("Kiran Kumar");
  const [stolenVal, setStolenVal] = useState<number>(350000);
  const [narrative, setNarrative] = useState<string>(
    "Victim received job offer message via WhatsApp promising high returns for rating hotel reviews. Transferred funds into mule accounts via UPI."
  );
  const [moTagsText, setMoTagsText] = useState<string>("WhatsApp Scam, Hotel Review Fraud, Mule Accounts");

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const newFirNumber = `FIR/0${Math.floor(100 + Math.random() * 900)}/2026`;
    const newId = `KSP-2026-${district.slice(0, 3).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newIncident: Incident = {
      id: newId,
      firNumber: newFirNumber,
      district,
      policeStation: station,
      crimeCategory: category,
      crimeSubtype: subtype,
      dateTime: new Date().toISOString(),
      timeOfDay: timeSlot,
      locationName,
      coordinates: { lat: 12.9716, lng: 77.5946 },
      severity: "High",
      status: "Under Investigation",
      suspectIds: ["SUS-0812"],
      victimName,
      modusOperandi: narrative,
      moTags: moTagsText.split(",").map((t) => t.trim()),
      socioEconomicContext: {
        urbanizationLevel: "High",
        unemploymentRate: 6.5,
        povertyIndex: 3.2,
        populationDensitySqKm: 12000,
      },
      narrative,
      isAnomaly: false,
      stolenValueINR: stolenVal,
    };

    onAddIncident(newIncident);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-xl w-full p-6 space-y-4 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 cursor-pointer p-1"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3 border-b border-slate-800 pb-3">
          <div className="w-10 h-10 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <PlusCircle className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-mono text-amber-400 font-bold uppercase">
              Automated Data Ingestion • SCRB
            </span>
            <h3 className="text-base font-bold text-slate-100">
              Ingest Raw Crime Incident into State Database
            </h3>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 font-medium mb-1">District:</label>
              <select
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded p-2 focus:outline-none focus:border-amber-500"
              >
                {districtsList.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Police Station:</label>
              <input
                type="text"
                value={station}
                onChange={(e) => setStation(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded p-2 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 font-medium mb-1">Crime Category:</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as CrimeCategory)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded p-2 focus:outline-none focus:border-amber-500"
              >
                <option value="Cyber Crime">Cyber Crime</option>
                <option value="Property Crime">Property Crime</option>
                <option value="Violent Crime">Violent Crime</option>
                <option value="Organized Crime">Organized Crime</option>
                <option value="Narcotics">Narcotics</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Offense Subtype:</label>
              <input
                type="text"
                value={subtype}
                onChange={(e) => setSubtype(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded p-2 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 font-medium mb-1">Time Slot:</label>
              <select
                value={timeSlot}
                onChange={(e) => setTimeSlot(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded p-2 focus:outline-none focus:border-amber-500"
              >
                <option value="Morning (06:00-12:00)">Morning (06:00-12:00)</option>
                <option value="Afternoon (12:00-17:00)">Afternoon (12:00-17:00)</option>
                <option value="Evening (17:00-22:00)">Evening (17:00-22:00)</option>
                <option value="Night (22:00-06:00)">Night (22:00-06:00)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Stolen / Loss Value (INR):</label>
              <input
                type="number"
                value={stolenVal}
                onChange={(e) => setStolenVal(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded p-2 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-400 font-medium mb-1">Incident Location Name:</label>
            <input
              type="text"
              value={locationName}
              onChange={(e) => setLocationName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded p-2 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div>
            <label className="block text-slate-400 font-medium mb-1">FIR Narrative & Modus Operandi:</label>
            <textarea
              rows={3}
              value={narrative}
              onChange={(e) => setNarrative(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded p-2 focus:outline-none focus:border-amber-500 resize-none"
            />
          </div>

          <div>
            <label className="block text-slate-400 font-medium mb-1">MO Tags (Comma Separated):</label>
            <input
              type="text"
              value={moTagsText}
              onChange={(e) => setMoTagsText(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded p-2 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-4 py-2 rounded text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2 rounded text-xs cursor-pointer"
            >
              Commit Record to Database
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
