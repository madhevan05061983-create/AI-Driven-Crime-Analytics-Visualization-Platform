import React, { useState, useMemo } from "react";
import { Incident, DistrictSummary, CrimeCategory } from "../types/crime";
import {
  MapPin,
  Clock,
  AlertOctagon,
  Search,
  Filter,
  Flame,
  ShieldAlert,
  ChevronRight,
  TrendingUp,
  FileSpreadsheet,
  X,
  Layers,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

interface SpatiotemporalMapDashboardProps {
  incidents: Incident[];
  districts: DistrictSummary[];
  selectedDistrict: string;
  onSelectDistrict: (district: string) => void;
}

const CATEGORY_COLORS: Record<CrimeCategory, string> = {
  "Cyber Crime": "#3b82f6",
  "Violent Crime": "#ef4444",
  "Property Crime": "#f59e0b",
  "Organized Crime": "#8b5cf6",
  Narcotics: "#10b981",
  "Financial Fraud": "#ec4899",
};

const TIME_SLOTS = [
  "Morning (06:00-12:00)",
  "Afternoon (12:00-17:00)",
  "Evening (17:00-22:00)",
  "Night (22:00-06:00)",
];

export const SpatiotemporalMapDashboard: React.FC<SpatiotemporalMapDashboardProps> = ({
  incidents,
  districts,
  selectedDistrict,
  onSelectDistrict,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("ALL");
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [activeIncidentModal, setActiveIncidentModal] = useState<Incident | null>(null);
  const [selectedPinDistrict, setSelectedPinDistrict] = useState<DistrictSummary | null>(null);

  // Filtered incidents
  const filteredIncidents = useMemo(() => {
    return incidents.filter((inc) => {
      const matchDistrict =
        selectedDistrict === "ALL" || inc.district === selectedDistrict;
      const matchCategory =
        selectedCategory === "ALL" || inc.crimeCategory === selectedCategory;
      const matchTime =
        selectedTimeSlot === "ALL" || inc.timeOfDay === selectedTimeSlot;
      const matchSearch =
        searchQuery === "" ||
        inc.firNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        inc.locationName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        inc.policeStation.toLowerCase().includes(searchQuery.toLowerCase()) ||
        inc.modusOperandi.toLowerCase().includes(searchQuery.toLowerCase());

      return matchDistrict && matchCategory && matchTime && matchSearch;
    });
  }, [incidents, selectedDistrict, selectedCategory, selectedTimeSlot, searchQuery]);

  // Spatiotemporal Heatmap Matrix Data (Time of Day vs District or Category)
  const heatmapMatrix = useMemo(() => {
    const matrix: Record<string, Record<string, number>> = {};

    TIME_SLOTS.forEach((slot) => {
      matrix[slot] = {};
    });

    filteredIncidents.forEach((inc) => {
      const slot = inc.timeOfDay;
      const key = selectedDistrict === "ALL" ? inc.district : inc.policeStation;
      if (matrix[slot]) {
        matrix[slot][key] = (matrix[slot][key] || 0) + 1;
      }
    });

    return matrix;
  }, [filteredIncidents, selectedDistrict]);

  // Chart: Category Distribution
  const categoryData = useMemo(() => {
    const counts: Record<string, number> = {};
    filteredIncidents.forEach((inc) => {
      counts[inc.crimeCategory] = (counts[inc.crimeCategory] || 0) + 1;
    });

    return Object.entries(counts).map(([name, value]) => ({
      name,
      value,
      color: CATEGORY_COLORS[name as CrimeCategory] || "#94a3b8",
    }));
  }, [filteredIncidents]);

  // Emerging Trend Spikes
  const trendSpikes = useMemo(() => {
    return [
      {
        district: "Bengaluru Urban",
        station: "Indiranagar PS",
        category: "Cyber Crime",
        spikeRate: "+34% vs historical baseline",
        trigger: "Fake KSEB APK malware scam targeting mobile banking",
        severity: "Critical",
      },
      {
        district: "Mysuru",
        station: "Lashkar PS",
        category: "Property Crime",
        spikeRate: "+18% in twilight slot",
        trigger: "Pulsar motorcycle snatchers targeting unlit temple routes",
        severity: "High",
      },
      {
        district: "Belagavi",
        station: "Khade Bazar PS",
        category: "Violent Crime",
        spikeRate: "+28% midnight highway",
        trigger: "Spiked barricade truck ambushes on NH-48",
        severity: "Critical",
      },
      {
        district: "Mangaluru",
        station: "Kadri PS",
        category: "Organized Crime",
        spikeRate: "+42% extortion threat",
        trigger: "VOIP international spoofing requesting USDT crypto ransom",
        severity: "Critical",
      },
    ];
  }, []);

  return (
    <div className="space-y-6">
      {/* Top Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-400 font-medium">Total Registered Incidents</p>
            <h3 className="text-2xl font-bold text-slate-100 mt-1">{filteredIncidents.length}</h3>
            <p className="text-[11px] text-emerald-400 mt-1 font-medium flex items-center">
              <TrendingUp className="w-3 h-3 mr-1" />
              Automated SCRB Database Ingest
            </p>
          </div>
          <div className="w-12 h-12 rounded-lg bg-blue-950 border border-blue-800/60 flex items-center justify-center text-blue-400">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-400 font-medium">Active Crime Hotspots</p>
            <h3 className="text-2xl font-bold text-rose-400 mt-1">
              {districts.reduce((acc, d) => acc + d.highRiskHotspotsCount, 0)}
            </h3>
            <p className="text-[11px] text-rose-400 mt-1 font-medium flex items-center">
              <Flame className="w-3 h-3 mr-1 animate-pulse" />
              Pulsing Red-Zone Alert Active
            </p>
          </div>
          <div className="w-12 h-12 rounded-lg bg-rose-950 border border-rose-800/60 flex items-center justify-center text-rose-400">
            <Flame className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-400 font-medium">Average SCRB Solved Rate</p>
            <h3 className="text-2xl font-bold text-emerald-400 mt-1">79.2%</h3>
            <p className="text-[11px] text-slate-400 mt-1">Cross-district intelligence active</p>
          </div>
          <div className="w-12 h-12 rounded-lg bg-emerald-950 border border-emerald-800/60 flex items-center justify-center text-emerald-400">
            <ShieldAlert className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-400 font-medium">Peak Crime Window</p>
            <h3 className="text-xl font-bold text-amber-400 mt-1">Night (22:00-06:00)</h3>
            <p className="text-[11px] text-amber-300 mt-1 font-medium">54% of severe offenses</p>
          </div>
          <div className="w-12 h-12 rounded-lg bg-amber-950 border border-amber-800/60 flex items-center justify-center text-amber-400">
            <Clock className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Map & Interactive Hotspots Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive Visual Map of Karnataka Districts */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-indigo-400" />
                Karnataka State Crime Hotspot & District Map
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Interactive spatial visualization showing district clusters, police station pins & pulsing red-zone hotspots
              </p>
            </div>
            <div className="flex items-center space-x-2 text-xs">
              <span className="flex items-center text-slate-300 bg-slate-800 px-2.5 py-1 rounded border border-slate-700">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping mr-1.5"></span>
                Red Zone Hotspot
              </span>
              <span className="flex items-center text-slate-300 bg-slate-800 px-2.5 py-1 rounded border border-slate-700">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400 mr-1.5"></span>
                Moderate Activity
              </span>
            </div>
          </div>

          {/* Interactive Karnataka SVG / Canvas Map Container */}
          <div className="relative w-full h-[400px] bg-slate-950 rounded-lg border border-slate-800 overflow-hidden flex items-center justify-center p-4">
            {/* Dark Grid Background Effect */}
            <div className="absolute inset-0 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:16px_16px] opacity-40"></div>

            {/* Simulated Karnataka State Map SVG Outline */}
            <svg
              viewBox="0 0 800 600"
              className="w-full h-full max-h-[380px] drop-shadow-[0_0_15px_rgba(245,158,11,0.1)]"
            >
              {/* Karnataka State Boundary Path */}
              <path
                d="M 320 80 L 450 110 L 520 180 L 580 250 L 520 340 L 480 420 L 380 520 L 300 480 L 220 380 L 180 300 L 240 180 Z"
                fill="#0f172a"
                stroke="#334155"
                strokeWidth="2"
                strokeDasharray="4 4"
              />

              {/* District Connecting Web Lines */}
              {districts.map((d, i) => {
                if (i === 0) return null;
                const prev = districts[i - 1];
                const x1 = ((d.coordinates.lng - 74) / 4) * 500 + 150;
                const y1 = 500 - ((d.coordinates.lat - 12) / 6) * 400;
                const x2 = ((prev.coordinates.lng - 74) / 4) * 500 + 150;
                const y2 = 500 - ((prev.coordinates.lat - 12) / 6) * 400;

                return (
                  <line
                    key={`line-${i}`}
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke="#1e293b"
                    strokeWidth="1.5"
                  />
                );
              })}

              {/* District Hotspot Pins */}
              {districts.map((dist) => {
                // Map GPS coordinates to SVG canvas space
                const x = ((dist.coordinates.lng - 74.0) / 3.5) * 550 + 120;
                const y = 520 - ((dist.coordinates.lat - 12.0) / 5.8) * 440;
                const isSelected =
                  selectedDistrict === dist.districtName ||
                  selectedPinDistrict?.districtName === dist.districtName;
                const isHighRisk = dist.highRiskHotspotsCount >= 5;

                return (
                  <g
                    key={dist.districtName}
                    transform={`translate(${x}, ${y})`}
                    className="cursor-pointer transition-transform hover:scale-125"
                    onClick={() => {
                      onSelectDistrict(dist.districtName);
                      setSelectedPinDistrict(dist);
                    }}
                  >
                    {/* Pulsing Red Zone Ring for High Risk */}
                    {isHighRisk && (
                      <circle
                        r="22"
                        className="fill-rose-500/20 stroke-rose-500 animate-ping"
                        strokeWidth="1.5"
                      />
                    )}

                    {/* Outer Pin Circle */}
                    <circle
                      r="12"
                      className={`${
                        isSelected
                          ? "fill-amber-400 stroke-amber-200"
                          : isHighRisk
                          ? "fill-rose-600 stroke-rose-300"
                          : "fill-amber-600 stroke-amber-400"
                      } drop-shadow-md`}
                      strokeWidth="2"
                    />

                    {/* Inner Dot */}
                    <circle r="4" fill="#020617" />

                    {/* District Name Label */}
                    <text
                      y="-18"
                      textAnchor="middle"
                      className={`text-[11px] font-bold fill-slate-200 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] ${
                        isSelected ? "fill-amber-300 text-xs font-extrabold" : ""
                      }`}
                    >
                      {dist.districtName.split(" ")[0]}
                    </text>
                  </g>
                );
              })}
            </svg>

            {/* Map Overlay Card on Selection */}
            {selectedPinDistrict && (
              <div className="absolute bottom-3 left-3 right-3 bg-slate-900/95 backdrop-blur-md border border-slate-700/80 rounded-lg p-3 text-xs shadow-2xl flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-100">{selectedPinDistrict.districtName} HQ</h4>
                    <p className="text-[11px] text-slate-400">
                      {selectedPinDistrict.policeStationsCount} Police Stations • Dominant:{" "}
                      <span className="text-amber-300">{selectedPinDistrict.dominantCrimeCategory}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-4 font-mono text-[11px]">
                  <div>
                    <span className="text-slate-400">Incidents:</span>{" "}
                    <strong className="text-slate-200">{selectedPinDistrict.totalIncidents}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400">Solved Rate:</span>{" "}
                    <strong className="text-emerald-400">{selectedPinDistrict.solvedRatePercent}%</strong>
                  </div>
                  <div>
                    <span className="text-slate-400">Hotspots:</span>{" "}
                    <strong className="text-rose-400">{selectedPinDistrict.highRiskHotspotsCount} Red Zones</strong>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedPinDistrict(null)}
                  className="text-slate-400 hover:text-slate-200 cursor-pointer p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Emerging Trend Alerts & Red Zone Pulses */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <AlertOctagon className="w-4 h-4 text-rose-500 animate-pulse" />
              Emerging Trend Red-Zone Alerts
            </h3>
            <span className="text-[10px] bg-rose-950 text-rose-300 px-2 py-0.5 rounded font-mono border border-rose-800/60">
              SCRB Automated
            </span>
          </div>
          <p className="text-xs text-slate-400 mb-4">
            Visual triggers when a crime category spikes in a police division compared to historical baseline
          </p>

          <div className="space-y-3 overflow-y-auto max-h-[340px] pr-1">
            {trendSpikes.map((spike, idx) => (
              <div
                key={idx}
                className="bg-slate-950 border border-slate-800 hover:border-rose-800/80 rounded-lg p-3 transition-colors text-xs"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-slate-200 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                    {spike.district} ({spike.station})
                  </span>
                  <span className="text-[10px] font-mono font-bold text-rose-400 bg-rose-950/80 px-2 py-0.5 rounded border border-rose-800/50">
                    {spike.spikeRate}
                  </span>
                </div>
                <div className="text-slate-400 text-[11px] mt-1">
                  <strong className="text-amber-400">{spike.category}:</strong> {spike.trigger}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Spatiotemporal Matrix (Time of Day vs District) */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" />
              Spatiotemporal Crime Cluster Matrix (Time of Day x Jurisdiction)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Layering occurrence timing with police station jurisdictions to enable proactive PCR van deployment
            </p>
          </div>
          <div className="flex items-center space-x-2 text-xs">
            <span className="text-slate-400">Filter Category:</span>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-slate-800 border border-slate-700 text-slate-200 rounded px-2.5 py-1 focus:outline-none cursor-pointer"
            >
              <option value="ALL">All Categories</option>
              <option value="Cyber Crime">Cyber Crime</option>
              <option value="Violent Crime">Violent Crime</option>
              <option value="Property Crime">Property Crime</option>
              <option value="Organized Crime">Organized Crime</option>
              <option value="Narcotics">Narcotics</option>
            </select>
          </div>
        </div>

        {/* Matrix Grid Table */}
        <div className="overflow-x-auto rounded-lg border border-slate-800">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3 border-b border-slate-800">Time Window Slot</th>
                {districts.map((d) => (
                  <th key={d.districtName} className="p-3 border-b border-slate-800 text-center">
                    {d.districtName.split(" ")[0]}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 bg-slate-900 font-mono">
              {TIME_SLOTS.map((slot) => (
                <tr key={slot} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3 font-sans font-medium text-slate-200">{slot}</td>
                  {districts.map((d) => {
                    const count = heatmapMatrix[slot]?.[d.districtName] || 0;
                    const isHigh = count >= 2;
                    return (
                      <td key={d.districtName} className="p-3 text-center">
                        <span
                          className={`inline-block px-2.5 py-1 rounded-md text-xs font-bold ${
                            count === 0
                              ? "bg-slate-950 text-slate-600"
                              : isHigh
                              ? "bg-rose-950 text-rose-300 border border-rose-800 animate-pulse"
                              : "bg-amber-950/80 text-amber-300 border border-amber-800/60"
                          }`}
                        >
                          {count}
                        </span>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Analytics Charts & FIR Incident Ledger */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Crime Category Pie Breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 mb-1">
              <Layers className="w-4 h-4 text-blue-400" />
              Crime Typology Breakdown
            </h3>
            <p className="text-xs text-slate-400 mb-3">
              Distribution of offense categories in {selectedDistrict}
            </p>
          </div>

          <div className="h-[220px] w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: "#020617", borderColor: "#334155", color: "#f8fafc" }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px] mt-2">
            {categoryData.map((item) => (
              <div key={item.name} className="flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }}></span>
                <span className="text-slate-300 truncate">{item.name}:</span>
                <strong className="text-slate-100 font-mono">{item.value}</strong>
              </div>
            ))}
          </div>
        </div>

        {/* FIR Incident Ledger */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                State Crime Records Bureau (SCRB) FIR Ledger
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Showing {filteredIncidents.length} verified crime incidents with MO tags & suspect links
              </p>
            </div>

            {/* Search Box */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search FIR#, station, MO..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-slate-200 pl-8 pr-3 py-1.5 rounded-lg text-xs focus:outline-none focus:border-amber-500 w-52"
              />
            </div>
          </div>

          <div className="overflow-x-auto rounded-lg border border-slate-800 max-h-[300px]">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] sticky top-0 z-10">
                <tr>
                  <th className="p-3">FIR Number</th>
                  <th className="p-3">District & Station</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Time Slot</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 bg-slate-900/60">
                {filteredIncidents.map((inc) => (
                  <tr key={inc.id} className="hover:bg-slate-800/50 transition-colors">
                    <td className="p-3 font-mono font-bold text-amber-400">{inc.firNumber}</td>
                    <td className="p-3">
                      <div className="font-semibold text-slate-200">{inc.policeStation}</div>
                      <div className="text-[10px] text-slate-400">{inc.district}</div>
                    </td>
                    <td className="p-3">
                      <span
                        className="inline-block px-2 py-0.5 rounded text-[10px] font-bold"
                        style={{
                          backgroundColor: `${CATEGORY_COLORS[inc.crimeCategory]}20`,
                          color: CATEGORY_COLORS[inc.crimeCategory],
                          border: `1px solid ${CATEGORY_COLORS[inc.crimeCategory]}40`,
                        }}
                      >
                        {inc.crimeSubtype}
                      </span>
                    </td>
                    <td className="p-3 text-slate-300 font-mono text-[11px]">{inc.timeOfDay.split(" ")[0]}</td>
                    <td className="p-3">
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                        {inc.status}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <button
                        onClick={() => setActiveIncidentModal(inc)}
                        className="text-xs text-amber-400 hover:text-amber-300 font-bold inline-flex items-center cursor-pointer"
                      >
                        Details <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* FIR Detail Modal */}
      {activeIncidentModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-2xl w-full p-6 space-y-4 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setActiveIncidentModal(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 cursor-pointer p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-mono text-amber-400 font-bold">
                  {activeIncidentModal.firNumber} • {activeIncidentModal.id}
                </span>
                <h3 className="text-lg font-bold text-slate-100">
                  {activeIncidentModal.crimeSubtype} ({activeIncidentModal.crimeCategory})
                </h3>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono">
              <div>
                <span className="text-slate-500 block">District:</span>
                <strong className="text-slate-200">{activeIncidentModal.district}</strong>
              </div>
              <div>
                <span className="text-slate-500 block">Police Station:</span>
                <strong className="text-slate-200">{activeIncidentModal.policeStation}</strong>
              </div>
              <div>
                <span className="text-slate-500 block">Time Slot:</span>
                <strong className="text-slate-200">{activeIncidentModal.timeOfDay}</strong>
              </div>
              <div>
                <span className="text-slate-500 block">Status:</span>
                <strong className="text-emerald-400">{activeIncidentModal.status}</strong>
              </div>
              <div>
                <span className="text-slate-500 block">Severity:</span>
                <strong className="text-rose-400">{activeIncidentModal.severity}</strong>
              </div>
              <div>
                <span className="text-slate-500 block">Stolen Value:</span>
                <strong className="text-amber-300">
                  {activeIncidentModal.stolenValueINR
                    ? `₹${activeIncidentModal.stolenValueINR.toLocaleString("en-IN")}`
                    : "N/A"}
                </strong>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Modus Operandi (MO) & Execution Signature
              </h4>
              <p className="text-xs text-slate-300 bg-slate-950 p-3 rounded border border-slate-800 leading-relaxed">
                {activeIncidentModal.modusOperandi}
              </p>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {activeIncidentModal.moTags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="text-[10px] font-mono bg-amber-950/80 text-amber-300 px-2 py-0.5 rounded border border-amber-800/60"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Investigative Narrative
              </h4>
              <p className="text-xs text-slate-400 bg-slate-950 p-3 rounded border border-slate-800 leading-relaxed">
                {activeIncidentModal.narrative}
              </p>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setActiveIncidentModal(null)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-4 py-2 rounded text-xs font-semibold cursor-pointer"
              >
                Close Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
