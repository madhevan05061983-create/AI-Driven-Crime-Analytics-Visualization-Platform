import React, { useState, useMemo } from "react";
import { Suspect, NetworkNode, NetworkEdge, Incident } from "../types/crime";
import {
  Users,
  GitBranch,
  ShieldAlert,
  Search,
  Zap,
  Phone,
  Car,
  Tag,
  AlertCircle,
  ExternalLink,
  ChevronRight,
  Sparkles,
} from "lucide-react";

interface CriminologicalNetworkViewProps {
  suspects: Suspect[];
  nodes: NetworkNode[];
  edges: NetworkEdge[];
  incidents: Incident[];
  selectedDistrict: string;
}

export const CriminologicalNetworkView: React.FC<CriminologicalNetworkViewProps> = ({
  suspects,
  nodes,
  edges,
  incidents,
  selectedDistrict,
}) => {
  const [selectedNodeType, setSelectedNodeType] = useState<string>("ALL");
  const [selectedNodeId, setSelectedNodeId] = useState<string>("SUS-0492");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [highlightHiddenLinks, setHighlightHiddenLinks] = useState<boolean>(true);

  // Filtered nodes
  const filteredNodes = useMemo(() => {
    return nodes.filter((n) => {
      const matchType = selectedNodeType === "ALL" || n.type === selectedNodeType;
      const matchSearch =
        searchTerm === "" ||
        n.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
        n.id.toLowerCase().includes(searchTerm.toLowerCase());
      return matchType && matchSearch;
    });
  }, [nodes, selectedNodeType, searchTerm]);

  // Selected node details
  const activeNode = useMemo(() => {
    return nodes.find((n) => n.id === selectedNodeId) || nodes[0];
  }, [nodes, selectedNodeId]);

  // Active Suspect Dossier (if selected node is a suspect)
  const activeSuspect = useMemo(() => {
    if (!activeNode || activeNode.type !== "Suspect") {
      return suspects.find((s) => s.id === "SUS-0492") || suspects[0];
    }
    return suspects.find((s) => s.id === activeNode.id) || suspects[0];
  }, [suspects, activeNode]);

  // Connected edges for active node
  const connectedEdges = useMemo(() => {
    if (!activeNode) return [];
    return edges.filter(
      (e) => e.source === activeNode.id || e.target === activeNode.id
    );
  }, [edges, activeNode]);

  // Cross-jurisdiction multi-station incident links for selected suspect
  const suspectLinkedIncidents = useMemo(() => {
    if (!activeSuspect) return [];
    return incidents.filter((inc) =>
      activeSuspect.linkedIncidentIds.includes(inc.id)
    );
  }, [incidents, activeSuspect]);

  // Hidden Association Detection Insights
  const hiddenAssociations = useMemo(() => {
    return [
      {
        title: "Cross-District Hardware & Digital Linkage",
        description:
          "SUS-0492 (Vikram Gowda) and SUS-0812 (Syed Sameer) share the same mule SIM card (+91 97312 88401) across 3 police stations in Bengaluru Urban and Hubballi-Dharwad.",
        confidence: 96,
        impact: "Links night burglary spree to APK banking malware ring.",
      },
      {
        title: "Syndicate Financing & Crypto Wallet",
        description:
          "SUS-0812 (Syed Sameer) provides USDT payment routing for SUS-0910 (Rashid Bawa) in Mangaluru extortion cases.",
        confidence: 91,
        impact: "Exposes cross-coastal organized extortion gateway.",
      },
      {
        title: "Repeat MO Vehicle Sharing",
        description:
          "Black Pulsar KA-09-EV-4021 logged in Mysuru chain snatching (FIR 0088) matches vehicle spotted near SUV OBD theft in Hubballi (FIR 0112).",
        confidence: 88,
        impact: "Links two distinct property theft syndicates.",
      },
    ];
  }, []);

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-bold text-amber-400 uppercase tracking-wider mb-1">
            <GitBranch className="w-4 h-4" />
            <span>Criminological Network & Link Engine • SCRB</span>
          </div>
          <h2 className="text-xl font-bold text-slate-100">
            Organized Crime Relationship & Multi-Station Association Graph
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Replaces isolated Excel spreadsheets by dynamically connecting suspects, victims, recurring locations, MO tags, mule phones, and vehicle assets across police station boundaries.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => setHighlightHiddenLinks(!highlightHiddenLinks)}
            className={`inline-flex items-center space-x-2 text-xs font-bold px-3.5 py-2 rounded-lg transition-colors cursor-pointer ${
              highlightHiddenLinks
                ? "bg-amber-500 text-slate-950 shadow-md"
                : "bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700"
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>{highlightHiddenLinks ? "Hidden Associations Active" : "Highlight Associations"}</span>
          </button>
        </div>
      </div>

      {/* Main Interactive Node-Link Canvas & Dossier Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive Node-Link Canvas (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div className="flex items-center space-x-2">
              <span className="text-xs text-slate-400 font-medium">Filter Node Type:</span>
              <select
                value={selectedNodeType}
                onChange={(e) => setSelectedNodeType(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-slate-200 text-xs px-2.5 py-1 rounded focus:outline-none cursor-pointer"
              >
                <option value="ALL">All Nodes ({nodes.length})</option>
                <option value="Suspect">Suspects</option>
                <option value="Incident">Incidents</option>
                <option value="Gang">Gangs / Syndicates</option>
                <option value="MOTag">MO Tags</option>
                <option value="Vehicle">Vehicles</option>
                <option value="Phone">Phones / Devices</option>
              </select>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
              <input
                type="text"
                placeholder="Find suspect, gang, MO..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-slate-200 text-xs pl-8 pr-3 py-1 rounded focus:outline-none focus:border-amber-500 w-48"
              />
            </div>
          </div>

          {/* Interactive Graph Canvas Area */}
          <div className="relative w-full h-[460px] bg-slate-950 rounded-lg border border-slate-800 overflow-hidden flex items-center justify-center p-4">
            {/* Subtle Grid Pattern */}
            <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:20px_20px] opacity-60"></div>

            <svg viewBox="0 0 800 500" className="w-full h-full">
              {/* Edges / Relationship Lines */}
              {edges.map((edge) => {
                const srcNode = nodes.find((n) => n.id === edge.source);
                const tgtNode = nodes.find((n) => n.id === edge.target);

                if (!srcNode || !tgtNode) return null;

                // Fixed layout positions mapped for aesthetic graph representation
                const nodePositions: Record<string, { x: number; y: number }> = {
                  "SUS-0492": { x: 380, y: 220 },
                  "SUS-0812": { x: 520, y: 150 },
                  "SUS-0723": { x: 260, y: 320 },
                  "SUS-0910": { x: 620, y: 300 },
                  "SUS-0511": { x: 420, y: 380 },
                  "KSP-2026-BLR-8921": { x: 480, y: 80 },
                  "KSP-2026-BLR-8945": { x: 280, y: 140 },
                  "KSP-2026-MYS-3021": { x: 160, y: 280 },
                  "KSP-2026-MNG-1102": { x: 680, y: 200 },
                  "KSP-2026-BEL-4190": { x: 540, y: 420 },
                  "KSP-2026-HUB-2281": { x: 220, y: 200 },
                  "GANG-01": { x: 420, y: 140 },
                  "GANG-02": { x: 660, y: 380 },
                  "GANG-03": { x: 320, y: 420 },
                  "MO-APK": { x: 600, y: 80 },
                  "MO-BOLT": { x: 200, y: 100 },
                  "MO-SPIKE": { x: 520, y: 460 },
                  "VEH-PULSAR": { x: 120, y: 360 },
                  "PHONE-MULE": { x: 620, y: 140 },
                };

                const pos1 = nodePositions[edge.source] || { x: 200, y: 200 };
                const pos2 = nodePositions[edge.target] || { x: 400, y: 400 };

                const isConnectedToSelected =
                  edge.source === selectedNodeId || edge.target === selectedNodeId;

                return (
                  <g key={edge.id}>
                    <line
                      x1={pos1.x}
                      y1={pos1.y}
                      x2={pos2.x}
                      y2={pos2.y}
                      stroke={
                        isConnectedToSelected
                          ? "#f59e0b"
                          : highlightHiddenLinks && edge.relationship === "ASSOCIATE_OF"
                          ? "#f43f5e"
                          : "#334155"
                      }
                      strokeWidth={isConnectedToSelected ? 2.5 : 1.2}
                      strokeDasharray={edge.relationship === "ASSOCIATE_OF" ? "4 3" : undefined}
                    />

                    {/* Edge Label */}
                    {isConnectedToSelected && (
                      <text
                        x={(pos1.x + pos2.x) / 2}
                        y={(pos1.y + pos2.y) / 2 - 4}
                        textAnchor="middle"
                        className="text-[9px] fill-amber-300 font-mono font-bold bg-slate-950 px-1"
                      >
                        {edge.relationship}
                      </text>
                    )}
                  </g>
                );
              })}

              {/* Graph Nodes */}
              {filteredNodes.map((n) => {
                const nodePositions: Record<string, { x: number; y: number }> = {
                  "SUS-0492": { x: 380, y: 220 },
                  "SUS-0812": { x: 520, y: 150 },
                  "SUS-0723": { x: 260, y: 320 },
                  "SUS-0910": { x: 620, y: 300 },
                  "SUS-0511": { x: 420, y: 380 },
                  "KSP-2026-BLR-8921": { x: 480, y: 80 },
                  "KSP-2026-BLR-8945": { x: 280, y: 140 },
                  "KSP-2026-MYS-3021": { x: 160, y: 280 },
                  "KSP-2026-MNG-1102": { x: 680, y: 200 },
                  "KSP-2026-BEL-4190": { x: 540, y: 420 },
                  "KSP-2026-HUB-2281": { x: 220, y: 200 },
                  "GANG-01": { x: 420, y: 140 },
                  "GANG-02": { x: 660, y: 380 },
                  "GANG-03": { x: 320, y: 420 },
                  "MO-APK": { x: 600, y: 80 },
                  "MO-BOLT": { x: 200, y: 100 },
                  "MO-SPIKE": { x: 520, y: 460 },
                  "VEH-PULSAR": { x: 120, y: 360 },
                  "PHONE-MULE": { x: 620, y: 140 },
                };

                const pos = nodePositions[n.id] || { x: 300, y: 250 };
                const isSelected = n.id === selectedNodeId;

                const nodeColors: Record<string, string> = {
                  Suspect: "#ef4444",
                  Incident: "#f59e0b",
                  Gang: "#8b5cf6",
                  MOTag: "#3b82f6",
                  Vehicle: "#10b981",
                  Phone: "#ec4899",
                };

                const color = nodeColors[n.type] || "#94a3b8";

                return (
                  <g
                    key={n.id}
                    transform={`translate(${pos.x}, ${pos.y})`}
                    className="cursor-pointer transition-transform hover:scale-125"
                    onClick={() => setSelectedNodeId(n.id)}
                  >
                    {/* Ring Halo for Selection */}
                    {isSelected && (
                      <circle
                        r="20"
                        fill="none"
                        stroke="#f59e0b"
                        strokeWidth="2"
                        className="animate-ping opacity-75"
                      />
                    )}

                    {/* Node Circle */}
                    <circle
                      r={isSelected ? 16 : 12}
                      fill={color}
                      stroke={isSelected ? "#fef08a" : "#020617"}
                      strokeWidth="2"
                      className="shadow-md"
                    />

                    {/* Inner Icon or Letter */}
                    <text
                      y="4"
                      textAnchor="middle"
                      className="text-[9px] font-extrabold fill-slate-950 font-mono"
                    >
                      {n.type === "Suspect"
                        ? "S"
                        : n.type === "Incident"
                        ? "FIR"
                        : n.type === "Gang"
                        ? "G"
                        : "N"}
                    </text>

                    {/* Node Label Text */}
                    <text
                      y={isSelected ? 28 : 24}
                      textAnchor="middle"
                      className={`text-[10px] font-bold fill-slate-200 drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)] ${
                        isSelected ? "fill-amber-300 text-[11px]" : ""
                      }`}
                    >
                      {n.label.split(" ")[0]}
                    </text>
                  </g>
                );
              })}
            </svg>

            {/* Legend Overlay */}
            <div className="absolute bottom-3 right-3 bg-slate-900/90 backdrop-blur-sm border border-slate-800 p-2.5 rounded-lg text-[10px] space-y-1.5 shadow-xl">
              <div className="font-bold text-slate-300 mb-1">Graph Legend</div>
              <div className="grid grid-cols-2 gap-x-3 gap-y-1">
                <div className="flex items-center space-x-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                  <span className="text-slate-300">Suspect</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                  <span className="text-slate-300">FIR Incident</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
                  <span className="text-slate-300">Gang / Syndicate</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                  <span className="text-slate-300">MO Signature</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Selected Suspect Dossier Card (Right Col) */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-mono text-amber-400 font-bold">
                {activeSuspect.id} • DOSSIER
              </span>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                  activeSuspect.status === "Absconding"
                    ? "bg-rose-950 text-rose-300 border border-rose-800 animate-pulse"
                    : "bg-slate-800 text-slate-300"
                }`}
              >
                {activeSuspect.status}
              </span>
            </div>

            {/* Suspect Header */}
            <div className="flex items-center space-x-3 mt-4">
              <div className="w-12 h-12 rounded-xl bg-slate-950 border border-slate-700 flex items-center justify-center font-bold text-slate-200 text-lg shadow-inner shrink-0">
                <Users className="w-6 h-6 text-amber-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-100">{activeSuspect.name}</h3>
                <p className="text-xs text-slate-400">
                  Alias: <span className="text-amber-300 font-medium">"{activeSuspect.alias || "N/A"}"</span> • Age {activeSuspect.age}
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Primary Jurisdiction: <strong className="text-slate-200">{activeSuspect.district}</strong>
                </p>
              </div>
            </div>

            {/* Risk Score Meter */}
            <div className="mt-4 bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400 font-medium">Criminological Risk Score:</span>
                <strong className="text-rose-400 font-mono">{activeSuspect.riskScore}/100</strong>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-amber-500 to-rose-600 h-full rounded-full transition-all duration-500"
                  style={{ width: `${activeSuspect.riskScore}%` }}
                ></div>
              </div>
            </div>

            {/* Modus Operandi & Multi-Jurisdiction Links */}
            <div className="mt-4 space-y-3 text-xs">
              <div>
                <h4 className="font-bold text-slate-300 uppercase text-[10px] tracking-wider mb-1">
                  Signature Modus Operandi (MO)
                </h4>
                <p className="text-slate-300 bg-slate-950 p-2.5 rounded border border-slate-800 leading-relaxed text-[11px]">
                  {activeSuspect.moPattern}
                </p>
              </div>

              <div>
                <h4 className="font-bold text-slate-300 uppercase text-[10px] tracking-wider mb-1">
                  Linked Cases Across Police Stations ({suspectLinkedIncidents.length})
                </h4>
                <div className="space-y-1.5">
                  {suspectLinkedIncidents.map((inc) => (
                    <div
                      key={inc.id}
                      className="bg-slate-950 p-2 rounded border border-slate-800 flex items-center justify-between font-mono text-[11px]"
                    >
                      <div>
                        <span className="text-amber-400 font-bold mr-2">{inc.firNumber}</span>
                        <span className="text-slate-300">{inc.policeStation}</span>
                      </div>
                      <span className="text-slate-400 text-[10px]">{inc.crimeCategory}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Known Assets / Mule Contacts */}
              <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                {activeSuspect.vehicleRegNo && (
                  <div className="bg-slate-950 p-2 rounded border border-slate-800 flex items-center space-x-1.5">
                    <Car className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="text-slate-300 truncate">{activeSuspect.vehicleRegNo}</span>
                  </div>
                )}
                {activeSuspect.phoneNumber && (
                  <div className="bg-slate-950 p-2 rounded border border-slate-800 flex items-center space-x-1.5">
                    <Phone className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span className="text-slate-300 truncate">{activeSuspect.phoneNumber}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800">
            <div className="text-[11px] text-slate-400 flex items-center justify-between">
              <span>Gang: <strong className="text-purple-300">{activeSuspect.gangName || "Independent"}</strong></span>
              <span>Last Track: <strong className="text-slate-200">{activeSuspect.lastKnownLocation}</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* Association Detection Callouts */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            AI-Discovered Hidden Associations (Cross-Jurisdiction)
          </h3>
          <span className="text-xs text-slate-400 font-mono">3 Inter-Station Correlations Flagged</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {hiddenAssociations.map((assoc, idx) => (
            <div
              key={idx}
              className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-2 text-xs hover:border-amber-500/60 transition-colors"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-300">{assoc.title}</span>
                <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800/60">
                  {assoc.confidence}% Match
                </span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">{assoc.description}</p>
              <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-900 font-mono">
                Impact: <span className="text-slate-200">{assoc.impact}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
