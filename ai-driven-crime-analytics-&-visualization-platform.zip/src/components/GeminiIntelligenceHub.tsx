import React, { useState } from "react";
import { Incident } from "../types/crime";
import {
  MessageSquare,
  Sparkles,
  FileText,
  Send,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Shield,
  Download,
  Copy,
  Tag,
  GitBranch,
} from "lucide-react";

interface GeminiIntelligenceHubProps {
  incidents: Incident[];
  selectedDistrict: string;
}

export const GeminiIntelligenceHub: React.FC<GeminiIntelligenceHubProps> = ({
  incidents,
  selectedDistrict,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<"mo-extractor" | "report-gen" | "ai-chat">("mo-extractor");

  // State 1: MO Extractor
  const [rawNarrativeInput, setRawNarrativeInput] = useState<string>(
    "Complainant reported that on 21/07/2026 around 02:15 AM, two unknown individuals arrived on a dark sports motorcycle without registration plates near 100ft Road Indiranagar. They used a heavy bolt cutter to break window grills of an independent house, disconnected the home Wi-Fi fiber router to disable IP cameras, and looted gold jewelry. Suspects communicated via encrypted mobile application."
  );
  const [inputCategory, setInputCategory] = useState<string>("Property Crime");
  const [isExtractingMO, setIsExtractingMO] = useState<boolean>(false);
  const [extractedResult, setExtractedResult] = useState<any>(null);
  const [moError, setMoError] = useState<string | null>(null);

  // State 2: Report Generator
  const [isGeneratingReport, setIsGeneratingReport] = useState<boolean>(false);
  const [generatedReportMarkdown, setGeneratedReportMarkdown] = useState<string | null>(null);

  // State 3: AI Chat Assistant
  const [chatMessages, setChatMessages] = useState<
    { sender: "user" | "ai"; text: string; time: string }[]
  >([
    {
      sender: "ai",
      text: "Namaskara Officer. I am KSP-AI, your State Crime Records Bureau Intelligence Assistant. How can I assist you with district crime patterns, suspect cross-linking, or MO profiling today?",
      time: "Just now",
    },
  ]);
  const [chatInput, setChatInput] = useState<string>("");
  const [isSendingChat, setIsSendingChat] = useState<boolean>(false);

  // Handler 1: Call /api/gemini/analyze-mo
  const handleExtractMO = async () => {
    if (!rawNarrativeInput.trim()) return;
    setIsExtractingMO(true);
    setMoError(null);
    setExtractedResult(null);

    try {
      const res = await fetch("/api/gemini/analyze-mo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          narrative: rawNarrativeInput,
          district: selectedDistrict === "ALL" ? "Bengaluru Urban" : selectedDistrict,
          crimeCategory: inputCategory,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setExtractedResult(data.data);
      } else {
        setMoError(data.error || "Failed to extract MO");
      }
    } catch (err: any) {
      console.error(err);
      setMoError(err?.message || "Server connection error");
    } finally {
      setIsExtractingMO(false);
    }
  };

  // Handler 2: Call /api/gemini/generate-report
  const handleGenerateReport = async () => {
    setIsGeneratingReport(true);
    try {
      const res = await fetch("/api/gemini/generate-report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          district: selectedDistrict,
          timeRange: "Q3 2026",
          focusCategory: "Spatiotemporal Hotspots, Cyber Fraud & Organized Syndicates",
          summaryStats: {
            totalIncidents: incidents.length,
            highRiskDistricts: 4,
            repeatOffendersLinked: 8,
          },
        }),
      });

      const data = await res.json();
      if (data.success) {
        setGeneratedReportMarkdown(data.report);
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsGeneratingReport(false);
    }
  };

  // Handler 3: Call /api/gemini/chat
  const handleSendChat = async () => {
    if (!chatInput.trim() || isSendingChat) return;

    const userText = chatInput;
    setChatInput("");
    setChatMessages((prev) => [
      ...prev,
      { sender: "user", text: userText, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
    ]);
    setIsSendingChat(true);

    try {
      const res = await fetch("/api/gemini/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userText,
          contextData: {
            selectedDistrict,
            totalIncidentsInDatabase: incidents.length,
            sampleIncidents: incidents.slice(0, 3).map((i) => ({
              fir: i.firNumber,
              district: i.district,
              mo: i.modusOperandi,
            })),
          },
        }),
      });

      const data = await res.json();
      if (data.success) {
        setChatMessages((prev) => [
          ...prev,
          {
            sender: "ai",
            text: data.reply,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsSendingChat(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-bold text-amber-400 uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4" />
            <span>KSP SCRB Gemini AI Intelligence Engine</span>
          </div>
          <h2 className="text-xl font-bold text-slate-100">
            Automated MO Extractor, SCRB Report Generator & AI Assistant
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Leverages Gemini 3.6 Flash on the server to extract Modus Operandi signatures from FIR narratives, generate evidence-based SCRB prevention briefs, and answer officer queries in real-time.
          </p>
        </div>

        {/* Sub-tab navigation */}
        <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
          <button
            onClick={() => setActiveSubTab("mo-extractor")}
            className={`px-3 py-1.5 rounded font-bold transition-colors cursor-pointer ${
              activeSubTab === "mo-extractor"
                ? "bg-amber-500 text-slate-950 shadow"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            MO Extractor
          </button>
          <button
            onClick={() => setActiveSubTab("report-gen")}
            className={`px-3 py-1.5 rounded font-bold transition-colors cursor-pointer ${
              activeSubTab === "report-gen"
                ? "bg-amber-500 text-slate-950 shadow"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            SCRB Report Draft
          </button>
          <button
            onClick={() => setActiveSubTab("ai-chat")}
            className={`px-3 py-1.5 rounded font-bold transition-colors cursor-pointer ${
              activeSubTab === "ai-chat"
                ? "bg-amber-500 text-slate-950 shadow"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Ask KSP Assistant
          </button>
        </div>
      </div>

      {/* SUB-TAB 1: MO EXTRACTOR */}
      {activeSubTab === "mo-extractor" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input Panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <FileText className="w-4 h-4 text-amber-400" />
                Raw FIR Incident Narrative Input
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Paste officer statement, victim complaint, or draft FIR to extract MO tags and suspect profile
              </p>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Crime Category:</label>
                <select
                  value={inputCategory}
                  onChange={(e) => setInputCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2.5 focus:outline-none focus:border-amber-500"
                >
                  <option value="Property Crime">Property Crime (House Burglary, Chain Snatching)</option>
                  <option value="Cyber Crime">Cyber Crime (APK Malicious Link, Banking Fraud)</option>
                  <option value="Violent Crime">Violent Crime (Highway Assault, Robbery)</option>
                  <option value="Organized Crime">Organized Crime (Extortion, Syndicate Threat)</option>
                  <option value="Narcotics">Narcotics & Contraband</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Incident Text / FIR Statement:</label>
                <textarea
                  rows={7}
                  value={rawNarrativeInput}
                  onChange={(e) => setRawNarrativeInput(e.target.value)}
                  placeholder="Paste complaint statement..."
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-3 text-xs focus:outline-none focus:border-amber-500 font-sans leading-relaxed resize-none"
                />
              </div>

              <button
                onClick={handleExtractMO}
                disabled={isExtractingMO || !rawNarrativeInput.trim()}
                className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs py-2.5 rounded-lg transition-colors flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
              >
                {isExtractingMO ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Analyzing MO Narrative with Gemini AI...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Extract Modus Operandi & Cross-District Linkage</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Result Panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              AI Extracted MO & Suspect Profiling Intelligence
            </h3>

            {!extractedResult && !isExtractingMO && !moError && (
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-8 text-center text-slate-400 text-xs space-y-2">
                <Sparkles className="w-8 h-8 text-amber-500/60 mx-auto" />
                <p>Click "Extract Modus Operandi" to run server-side Gemini intelligence analysis on the narrative.</p>
              </div>
            )}

            {moError && (
              <div className="bg-rose-950/60 border border-rose-800 text-rose-300 p-4 rounded-lg text-xs flex items-center space-x-2">
                <AlertCircle className="w-5 h-5 shrink-0 text-rose-400" />
                <span>Error: {moError}</span>
              </div>
            )}

            {extractedResult && (
              <div className="space-y-4 text-xs">
                {/* Extracted MO Summary */}
                <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg space-y-1.5">
                  <span className="font-bold text-amber-400 uppercase text-[10px] tracking-wider block">
                    Extracted Modus Operandi
                  </span>
                  <p className="text-slate-200 leading-relaxed font-medium">{extractedResult.extractedMO}</p>
                </div>

                {/* MO Tags */}
                <div>
                  <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block mb-1.5">
                    Extracted MO Signature Tags
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {extractedResult.moTags?.map((tag: string, i: number) => (
                      <span
                        key={i}
                        className="bg-amber-950/80 text-amber-300 border border-amber-800/60 px-2.5 py-1 rounded text-[11px] font-mono font-bold"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Suspect Profile */}
                <div className="grid grid-cols-2 gap-3 bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Estimated Age Group:</span>
                    <strong className="text-slate-200">{extractedResult.suspectProfile?.estimatedAgeGroup}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Modus Type:</span>
                    <strong className="text-slate-200">{extractedResult.suspectProfile?.modusType}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Probable Vehicle:</span>
                    <strong className="text-slate-200">{extractedResult.suspectProfile?.probableVehicle}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Assessed Risk Severity:</span>
                    <strong className="text-rose-400 font-bold">{extractedResult.riskSeverity}</strong>
                  </div>
                </div>

                {/* Cross-District Linkages */}
                <div>
                  <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block mb-1.5">
                    Cross-District Historical Incident Matches
                  </span>
                  <div className="space-y-1.5">
                    {extractedResult.crossDistrictLinkages?.map((link: any, i: number) => (
                      <div key={i} className="bg-slate-950 p-2.5 rounded border border-slate-800 flex items-center justify-between text-[11px]">
                        <div>
                          <strong className="text-amber-300 mr-2">{link.district}:</strong>
                          <span className="text-slate-300">{link.similarPastMO}</span>
                        </div>
                        <span className="font-mono text-emerald-400 font-bold shrink-0 ml-2">
                          {link.confidenceScore}% match
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: SCRB REPORT GENERATOR */}
      {activeSubTab === "report-gen" && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-400" />
                State Crime Records Bureau (SCRB) Strategic Intelligence Brief
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Generate an official multi-section executive intelligence report for DGP / Superintendents
              </p>
            </div>

            <button
              onClick={handleGenerateReport}
              disabled={isGeneratingReport}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs px-4 py-2.5 rounded-lg transition-colors flex items-center space-x-2 cursor-pointer disabled:opacity-50"
            >
              {isGeneratingReport ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Drafting Official Report...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Official SCRB Report</span>
                </>
              )}
            </button>
          </div>

          {!generatedReportMarkdown && !isGeneratingReport && (
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-12 text-center text-slate-400 text-xs space-y-3">
              <FileText className="w-10 h-10 text-amber-500/60 mx-auto" />
              <p className="text-sm font-semibold text-slate-200">No Report Generated Yet</p>
              <p className="max-w-md mx-auto text-slate-400">
                Click "Generate Official SCRB Report" to draft an executive state-wide crime intelligence brief formatted in Markdown.
              </p>
            </div>
          )}

          {generatedReportMarkdown && (
            <div className="bg-slate-950 border border-slate-800 p-6 rounded-lg text-xs text-slate-200 space-y-4 font-sans leading-relaxed overflow-x-auto">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <span className="font-mono text-amber-400 font-bold uppercase">
                  CONFIDENTIAL • KSP SCRB OFFICIAL BRIEF
                </span>
                <span className="text-[11px] text-slate-400">{new Date().toLocaleDateString()}</span>
              </div>

              <div className="whitespace-pre-wrap font-sans text-slate-300 space-y-2">
                {generatedReportMarkdown}
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 3: AI ASSISTANT CHAT */}
      {activeSubTab === "ai-chat" && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4 flex flex-col h-[520px]">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full bg-emerald-400 animate-ping"></div>
              <h3 className="text-sm font-bold text-slate-100">KSP-AI Assistant (State Crime Query Engine)</h3>
            </div>
            <span className="text-[11px] font-mono text-slate-400">Powered by Gemini 3.6 Flash</span>
          </div>

          {/* Chat Stream */}
          <div className="flex-1 overflow-y-auto space-y-3 pr-2 scrollbar-thin">
            {chatMessages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-2xl rounded-lg p-3 text-xs space-y-1 ${
                    msg.sender === "user"
                      ? "bg-amber-500 text-slate-950 font-medium"
                      : "bg-slate-950 text-slate-200 border border-slate-800"
                  }`}
                >
                  <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                  <span className="text-[9px] opacity-70 block text-right font-mono">{msg.time}</span>
                </div>
              </div>
            ))}
            {isSendingChat && (
              <div className="flex justify-start">
                <div className="bg-slate-950 text-slate-400 border border-slate-800 p-3 rounded-lg text-xs flex items-center space-x-2">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-400" />
                  <span>Querying Karnataka SCRB database with Gemini...</span>
                </div>
              </div>
            )}
          </div>

          {/* Chat Input */}
          <div className="flex items-center space-x-2 border-t border-slate-800 pt-3">
            <input
              type="text"
              placeholder="Ask about crime trends, suspect networks, MO signatures..."
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSendChat()}
              className="flex-1 bg-slate-950 border border-slate-800 text-slate-200 text-xs px-3.5 py-2.5 rounded-lg focus:outline-none focus:border-amber-500"
            />
            <button
              onClick={handleSendChat}
              disabled={isSendingChat || !chatInput.trim()}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold p-2.5 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
