import React, { useState } from "react";
import { DistrictSummary, PredictiveRiskForecast, Incident } from "../types/crime";
import {
  TrendingUp,
  AlertTriangle,
  Users,
  Compass,
  Building,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  BarChart2,
  Zap,
} from "lucide-react";
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface SociologicalPredictiveDashboardProps {
  districts: DistrictSummary[];
  predictiveForecasts: PredictiveRiskForecast[];
  incidents: Incident[];
  selectedDistrict: string;
}

export const SociologicalPredictiveDashboard: React.FC<SociologicalPredictiveDashboardProps> = ({
  districts,
  predictiveForecasts,
  incidents,
  selectedDistrict,
}) => {
  const [activeMetric, setActiveMetric] = useState<"unemployment" | "urbanization" | "literacy">("unemployment");

  // Format chart data correlating socio-economic factors with incident count
  const correlationChartData = districts.map((d) => ({
    name: d.districtName.split(" ")[0],
    incidents: d.totalIncidents,
    unemployment: d.unemploymentPercent,
    urbanization: d.urbanizationPercent,
    literacy: d.literacyPercent,
    policeRatio: d.policePerLakhCitizens,
  }));

  // Filter anomalies
  const anomalousIncidents = incidents.filter((i) => i.isAnomaly);

  return (
    <div className="space-y-6">
      {/* Strategic Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-bold text-emerald-400 uppercase tracking-wider mb-1">
            <Compass className="w-4 h-4" />
            <span>SCRB Strategic Intelligence Hub • Proactive Policing</span>
          </div>
          <h2 className="text-xl font-bold text-slate-100">
            Socio-Economic Correlation, Anomaly Detection & AI Predictive Risk Scoring
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Transforms policing from reactive incident response to evidence-based proactive deterrence by correlating structural socio-economic variables (unemployment, urbanization, density) with forecasted crime risks.
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-2.5 flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="text-slate-400 font-medium">Predictive Model Accuracy</div>
              <div className="text-slate-100 font-bold font-mono">92.4% Precision Score</div>
            </div>
          </div>
        </div>
      </div>

      {/* Socio-Economic Correlation Charts */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-amber-400" />
              Socio-Economic Overlay Analysis ("Why" behind "Where")
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Correlating district-level socio-economic indicators against total registered incident volume
            </p>
          </div>

          <div className="flex items-center space-x-2 text-xs">
            <span className="text-slate-400">Select Overlay Metric:</span>
            <div className="bg-slate-950 p-1 rounded-lg border border-slate-800 flex space-x-1">
              <button
                onClick={() => setActiveMetric("unemployment")}
                className={`px-3 py-1 rounded text-xs font-bold transition-colors cursor-pointer ${
                  activeMetric === "unemployment"
                    ? "bg-amber-500 text-slate-950"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                Youth Unemployment %
              </button>
              <button
                onClick={() => setActiveMetric("urbanization")}
                className={`px-3 py-1 rounded text-xs font-bold transition-colors cursor-pointer ${
                  activeMetric === "urbanization"
                    ? "bg-amber-500 text-slate-950"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                Urbanization %
              </button>
            </div>
          </div>
        </div>

        {/* Composed Chart */}
        <div className="h-[280px] w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={correlationChartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 11 }} />
              <YAxis yAxisId="left" stroke="#f59e0b" tick={{ fontSize: 11 }} label={{ value: "Total Incidents", angle: -90, position: "insideLeft", fill: "#f59e0b", fontSize: 10 }} />
              <YAxis yAxisId="right" orientation="right" stroke="#38bdf8" tick={{ fontSize: 11 }} label={{ value: `${activeMetric.toUpperCase()} %`, angle: 90, position: "insideRight", fill: "#38bdf8", fontSize: 10 }} />
              <Tooltip contentStyle={{ backgroundColor: "#020617", borderColor: "#334155", color: "#f8fafc" }} />
              <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "10px" }} />
              <Bar yAxisId="left" dataKey="incidents" name="Registered Incidents" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              <Line yAxisId="right" type="monotone" dataKey={activeMetric} name={`Socio-Economic ${activeMetric} %`} stroke="#38bdf8" strokeWidth={3} dot={{ r: 5 }} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* AI Predictive Risk Scoring Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-500" />
                AI-Driven Predictive Risk Scoring (Next 7-30 Days Forecast)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Forecasted high-risk jurisdictions with recommended proactive police resource deployment
              </p>
            </div>
            <span className="text-xs font-mono bg-rose-950 text-rose-300 border border-rose-800 px-2.5 py-1 rounded">
              Statewide Risk Forecast
            </span>
          </div>

          <div className="space-y-3">
            {predictiveForecasts.map((forecast, idx) => (
              <div
                key={idx}
                className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3 hover:border-amber-500/60 transition-colors"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
                  <div>
                    <h4 className="font-bold text-slate-100 text-sm">{forecast.district}</h4>
                    <p className="text-xs text-amber-400 font-medium">{forecast.stationName}</p>
                  </div>

                  <div className="flex items-center space-x-3">
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block uppercase">Risk Score</span>
                      <strong className="text-rose-400 font-mono text-base">{forecast.predictedRiskScore}/100</strong>
                    </div>
                    <span className="text-[10px] font-mono font-bold bg-rose-950 text-rose-300 border border-rose-800 px-2 py-1 rounded">
                      {forecast.trendDirection} Risk
                    </span>
                  </div>
                </div>

                {/* Drivers & Recommended Deployment */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="space-y-1">
                    <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block">
                      Primary Risk Drivers
                    </span>
                    <ul className="space-y-1 text-slate-300 text-[11px] list-disc list-inside">
                      {forecast.primaryRiskDrivers.map((driver, i) => (
                        <li key={i}>{driver}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-slate-900 p-2.5 rounded border border-slate-800 space-y-1 text-[11px]">
                    <span className="font-bold text-emerald-400 uppercase text-[10px] tracking-wider block flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" /> Recommended Police Deployment
                    </span>
                    <div>
                      <span className="text-slate-400">PCR Vans Needed:</span>{" "}
                      <strong className="text-amber-300 font-mono">{forecast.recommendedDeployment.pcrVansNeeded} Units</strong>
                    </div>
                    <div>
                      <span className="text-slate-400">Patrol Window:</span>{" "}
                      <strong className="text-slate-200 font-mono">{forecast.recommendedDeployment.patrolTiming}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400">Hotspots:</span>{" "}
                      <span className="text-slate-300">{forecast.recommendedDeployment.focusHotspotAreas.join(", ")}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Anomaly Detection Log */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Zap className="w-4 h-4 text-purple-400" />
                Behavioral & Spatial Anomaly Detection
              </h3>
              <span className="text-[10px] bg-purple-950 text-purple-300 border border-purple-800/80 px-2 py-0.5 rounded font-mono">
                AI Outliers
              </span>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              Flagged incidents that significantly deviate from historical baseline patterns in local station jurisdictions
            </p>

            <div className="space-y-3 overflow-y-auto max-h-[380px] pr-1">
              {anomalousIncidents.map((anom) => (
                <div
                  key={anom.id}
                  className="bg-slate-950 border border-purple-900/60 rounded-lg p-3 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-purple-300 font-mono">{anom.firNumber}</span>
                    <span className="text-[10px] font-mono text-slate-400">{anom.district}</span>
                  </div>
                  <p className="font-semibold text-slate-200 text-[11px]">{anom.crimeSubtype}</p>
                  <p className="text-slate-400 text-[11px] bg-slate-900 p-2 rounded border border-slate-800">
                    <strong className="text-purple-400">Anomaly Reason:</strong> {anom.anomalyReason}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Model: <strong className="text-slate-200">KSP Anomaly-Net v2</strong></span>
            <span className="text-emerald-400 font-medium">Auto-Flag Active</span>
          </div>
        </div>
      </div>
    </div>
  );
};
