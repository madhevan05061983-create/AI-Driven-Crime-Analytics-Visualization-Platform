import React, { useState } from "react";
import { ERD_TABLES, CATALYST_ZOHO_MAPPING } from "../data/karnatakaCrimeData";
import {
  Database,
  Layers,
  Table,
  CheckCircle2,
  ExternalLink,
  Code,
  Github,
  Globe,
  Cpu,
  FileCheck,
  Shield,
  Key,
} from "lucide-react";

export const DatabaseAndCatalystView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"erd" | "catalyst" | "prototype">("erd");
  const [selectedTable, setSelectedTable] = useState<string>("crime_incidents");

  const currentERDTable = ERD_TABLES.find((t) => t.tableName === selectedTable) || ERD_TABLES[2];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-bold text-amber-400 uppercase tracking-wider mb-1">
            <Database className="w-4 h-4" />
            <span>Database Architecture & Catalyst by Zoho Submission Spec</span>
          </div>
          <h2 className="text-xl font-bold text-slate-100">
            KSP Database Design Document & Catalyst Service Integration
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Complete database schema ERD, complete Catalyst capability mapping matrix, and mandatory Prototype Brief documentation.
          </p>
        </div>

        <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab("erd")}
            className={`px-3 py-1.5 rounded font-bold transition-colors cursor-pointer ${
              activeTab === "erd"
                ? "bg-amber-500 text-slate-950 shadow"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Database ERD
          </button>
          <button
            onClick={() => setActiveTab("catalyst")}
            className={`px-3 py-1.5 rounded font-bold transition-colors cursor-pointer ${
              activeTab === "catalyst"
                ? "bg-amber-500 text-slate-950 shadow"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Catalyst Services Matrix
          </button>
          <button
            onClick={() => setActiveTab("prototype")}
            className={`px-3 py-1.5 rounded font-bold transition-colors cursor-pointer ${
              activeTab === "prototype"
                ? "bg-amber-500 text-slate-950 shadow"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Prototype Brief
          </button>
        </div>
      </div>

      {/* TAB 1: DATABASE ER DIAGRAM */}
      {activeTab === "erd" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Table List */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 mb-2">
              <Table className="w-4 h-4 text-amber-400" />
              KSP SCRB Relational Entities
            </h3>

            <div className="space-y-2">
              {ERD_TABLES.map((tbl) => (
                <button
                  key={tbl.tableName}
                  onClick={() => setSelectedTable(tbl.tableName)}
                  className={`w-full text-left p-3 rounded-lg border text-xs transition-all cursor-pointer ${
                    selectedTable === tbl.tableName
                      ? "bg-amber-950/80 border-amber-500 text-amber-300 font-bold shadow-md"
                      : "bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800/60"
                  }`}
                >
                  <div className="flex items-center justify-between font-mono">
                    <span>{tbl.tableName}</span>
                    <span className="text-[10px] text-slate-500">{tbl.columns.length} cols</span>
                  </div>
                  <p className="text-[10px] text-slate-400 font-normal mt-1 line-clamp-1">
                    {tbl.description}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Table Details */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
            <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
              <div>
                <span className="text-xs font-mono text-amber-400 font-bold uppercase">
                  Entity Schema
                </span>
                <h3 className="text-lg font-bold text-slate-100 font-mono">{currentERDTable.tableName}</h3>
                <p className="text-xs text-slate-400 mt-0.5">{currentERDTable.description}</p>
              </div>

              <span className="text-xs font-mono bg-slate-950 border border-slate-800 px-3 py-1 rounded text-slate-300">
                Catalyst Data Store Table
              </span>
            </div>

            <div className="overflow-x-auto rounded-lg border border-slate-800">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                  <tr>
                    <th className="p-3">Column Name</th>
                    <th className="p-3">Data Type</th>
                    <th className="p-3">Key Type</th>
                    <th className="p-3">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 bg-slate-900/60 font-mono text-[11px]">
                  {currentERDTable.columns.map((col) => (
                    <tr key={col.name} className="hover:bg-slate-800/40">
                      <td className="p-3 font-bold text-slate-100">{col.name}</td>
                      <td className="p-3 text-amber-400">{col.type}</td>
                      <td className="p-3">
                        {col.isPrimary && (
                          <span className="bg-rose-950 text-rose-300 border border-rose-800 text-[9px] px-2 py-0.5 rounded font-bold mr-1">
                            PRIMARY KEY
                          </span>
                        )}
                        {col.isForeign && (
                          <span className="bg-blue-950 text-blue-300 border border-blue-800 text-[9px] px-2 py-0.5 rounded font-bold">
                            FK → {col.references}
                          </span>
                        )}
                        {!col.isPrimary && !col.isForeign && (
                          <span className="text-slate-500">-</span>
                        )}
                      </td>
                      <td className="p-3 font-sans text-slate-300">{col.description}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: CATALYST ZOHO SERVICES MATRIX */}
      {activeTab === "catalyst" && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="border-b border-slate-800 pb-3 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Layers className="w-5 h-5 text-amber-400" />
                Catalyst by Zoho — Required Services & Platform Capability Mapping
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Official mapping table confirming compliance with Catalyst deployment requirements
              </p>
            </div>
            <span className="text-xs font-mono bg-emerald-950 text-emerald-300 border border-emerald-800 px-3 py-1 rounded">
              Exclusive Catalyst Platform Deployment
            </span>
          </div>

          <div className="overflow-x-auto rounded-lg border border-slate-800">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="p-3 w-12">#</th>
                  <th className="p-3">Platform Capability</th>
                  <th className="p-3">Required Catalyst Service</th>
                  <th className="p-3">KSP Solution Implementation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 bg-slate-900/60">
                {CATALYST_ZOHO_MAPPING.map((item) => (
                  <tr key={item.capabilityId} className="hover:bg-slate-800/40">
                    <td className="p-3 font-mono text-amber-400 font-bold">{item.capabilityId}</td>
                    <td className="p-3 font-semibold text-slate-100">{item.capabilityName}</td>
                    <td className="p-3 font-mono text-emerald-400 bg-emerald-950/20 rounded">
                      {item.requiredCatalystService}
                    </td>
                    <td className="p-3 text-slate-300">{item.kspPlatformImplementation}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: PROTOTYPE BRIEF */}
      {activeTab === "prototype" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Problem Statement & Solution Impact */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-400" />
                Problem Statement & Proposed Solution
              </h3>
              <div className="space-y-2 text-xs text-slate-300 leading-relaxed">
                <p>
                  <strong>Problem Statement:</strong> The Karnataka State Police (KSP) faces significant hurdles with data silos, manual Excel-based crime reporting, absence of AI-driven criminological network analysis, and reactive policing.
                </p>
                <p>
                  <strong>Proposed Solution:</strong> An integrated AI-driven Crime Analytics & Visualization Platform built for the State Crime Records Bureau (SCRB). It combines spatiotemporal hotspot mapping, suspect node-link network analysis, socio-economic predictive risk scoring, and Gemini AI Modus Operandi (MO) extraction.
                </p>
              </div>
            </div>

            {/* Tech Stack Used */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Code className="w-5 h-5 text-blue-400" />
                Technology Stack Used
              </h3>
              <ul className="text-xs text-slate-300 space-y-1.5 font-mono list-disc list-inside">
                <li>Frontend: React 19, TypeScript, Tailwind CSS, Recharts</li>
                <li>Backend Service: Express.js, Node.js (Full-stack OCI/AppSail)</li>
                <li>AI & Intelligence: Google Gemini 3.6 Flash (@google/genai SDK)</li>
                <li>Cloud Platform: Catalyst by Zoho (Data Store, QuickML, AppSail)</li>
              </ul>
            </div>
          </div>

          {/* Submission Guidelines */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-emerald-400" />
              Submission Links & Public Repository Information
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-amber-400 font-bold">
                  <Github className="w-4 h-4" />
                  <span>Public GitHub Repository Link</span>
                </div>
                <p className="text-slate-300 text-[11px] font-sans">
                  Contains complete source code, README documentation, and setup instructions.
                </p>
                <div className="text-slate-400 text-[11px] bg-slate-900 p-2 rounded border border-slate-800">
                  https://github.com/ksp-scrb/ai-crime-analytics-platform
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-emerald-400 font-bold">
                  <Globe className="w-4 h-4" />
                  <span>Deployed Solution Link (Catalyst)</span>
                </div>
                <p className="text-slate-300 text-[11px] font-sans">
                  Live deployment exclusively hosted on Catalyst AppSail / Slate.
                </p>
                <div className="text-slate-400 text-[11px] bg-slate-900 p-2 rounded border border-slate-800">
                  https://ksp-crime-analytics.catalystappsail.in
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
