import React, { useState } from "react";
import { Header } from "./components/Header";
import { SpatiotemporalMapDashboard } from "./components/SpatiotemporalMapDashboard";
import { CriminologicalNetworkView } from "./components/CriminologicalNetworkView";
import { SociologicalPredictiveDashboard } from "./components/SociologicalPredictiveDashboard";
import { GeminiIntelligenceHub } from "./components/GeminiIntelligenceHub";
import { DatabaseAndCatalystView } from "./components/DatabaseAndCatalystView";
import { RecordIngestionModal } from "./components/RecordIngestionModal";

import {
  KARNATAKA_DISTRICTS,
  MOCK_INCIDENTS,
  MOCK_SUSPECTS,
  NETWORK_NODES,
  NETWORK_EDGES,
  PREDICTIVE_RISK_FORECASTS,
} from "./data/karnatakaCrimeData";
import { Incident, NetworkNode, NetworkEdge } from "./types/crime";

export default function App() {
  const [activeTab, setActiveTab] = useState<
    "map" | "network" | "predictive" | "ai-hub" | "catalyst"
  >("map");
  const [selectedDistrict, setSelectedDistrict] = useState<string>("ALL");

  const [incidents, setIncidents] = useState<Incident[]>(MOCK_INCIDENTS);
  const [nodes, setNodes] = useState<NetworkNode[]>(NETWORK_NODES);
  const [edges, setEdges] = useState<NetworkEdge[]>(NETWORK_EDGES);
  const [isIngestModalOpen, setIsIngestModalOpen] = useState<boolean>(false);

  const districtsList = KARNATAKA_DISTRICTS.map((d) => d.districtName);

  const handleAddIncident = (newInc: Incident) => {
    setIncidents((prev) => [newInc, ...prev]);

    // Dynamically create a node for the new FIR
    const newIncNode: NetworkNode = {
      id: newInc.id,
      label: `${newInc.firNumber} (${newInc.crimeSubtype})`,
      type: "Incident",
      details: { district: newInc.district, category: newInc.crimeCategory },
    };

    setNodes((prev) => [newIncNode, ...prev]);

    // Link to suspect if available
    if (newInc.suspectIds.length > 0) {
      const newEdge: NetworkEdge = {
        id: `e-new-${Date.now()}`,
        source: newInc.suspectIds[0],
        target: newInc.id,
        relationship: "PERPETRATED_AT",
        label: "Primary Suspect",
      };
      setEdges((prev) => [...prev, newEdge]);
    }
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-300 font-sans antialiased selection:bg-indigo-600 selection:text-white flex flex-col justify-between">
      <div>
        {/* Official KSP Navbar */}
        <Header
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          selectedDistrict={selectedDistrict}
          setSelectedDistrict={setSelectedDistrict}
          districtsList={districtsList}
          onOpenIngestModal={() => setIsIngestModalOpen(true)}
        />

        {/* Main Content Area */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {activeTab === "map" && (
            <SpatiotemporalMapDashboard
              incidents={incidents}
              districts={KARNATAKA_DISTRICTS}
              selectedDistrict={selectedDistrict}
              onSelectDistrict={setSelectedDistrict}
            />
          )}

          {activeTab === "network" && (
            <CriminologicalNetworkView
              suspects={MOCK_SUSPECTS}
              nodes={nodes}
              edges={edges}
              incidents={incidents}
              selectedDistrict={selectedDistrict}
            />
          )}

          {activeTab === "predictive" && (
            <SociologicalPredictiveDashboard
              districts={KARNATAKA_DISTRICTS}
              predictiveForecasts={PREDICTIVE_RISK_FORECASTS}
              incidents={incidents}
              selectedDistrict={selectedDistrict}
            />
          )}

          {activeTab === "ai-hub" && (
            <GeminiIntelligenceHub
              incidents={incidents}
              selectedDistrict={selectedDistrict}
            />
          )}

          {activeTab === "catalyst" && <DatabaseAndCatalystView />}
        </main>
      </div>

      {/* Record Ingestion Modal */}
      <RecordIngestionModal
        isOpen={isIngestModalOpen}
        onClose={() => setIsIngestModalOpen(false)}
        onAddIncident={handleAddIncident}
        districtsList={districtsList}
      />

      {/* Sleek Mission Control Footer Bar */}
      <footer className="h-12 bg-slate-950 border-t border-slate-800 flex items-center justify-between px-6 shrink-0 font-mono text-[10px] text-slate-400 mt-8">
        <div className="flex items-center gap-4 sm:gap-6">
          <span className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            Catalyst AppSail: RUNNING
          </span>
          <span className="text-slate-700 hidden sm:inline">|</span>
          <span className="text-slate-400 hidden sm:inline">QuickML Model: V2.1.8-STABLE</span>
          <span className="text-slate-700 hidden md:inline">|</span>
          <span className="text-indigo-400 font-semibold hidden md:inline">Gemini AI Engine Active</span>
        </div>
        <div className="text-slate-500">
          System Secure • Terminal ID: KSP-BNG-9902 • State Crime Records Bureau
        </div>
      </footer>
    </div>
  );
}
